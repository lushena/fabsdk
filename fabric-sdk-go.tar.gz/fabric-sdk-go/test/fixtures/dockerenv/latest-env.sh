#!/bin/bash
#
# Copyright SecureKey Technologies Inc. All Rights Reserved.
#
# SPDX-License-Identifier: Apache-2.0
#

export FABRIC_DOCKER_REGISTRY=""
export FABRIC_CA_FIXTURE_TAG="latest"
export FABRIC_ORDERER_FIXTURE_TAG="latest"
export FABRIC_PEER_FIXTURE_TAG="latest"
export FABRIC_COUCHDB_FIXTURE_TAG="latest"
export FABRIC_BUILDER_FIXTURE_TAG="latest"
